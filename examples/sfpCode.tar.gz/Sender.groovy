class Sender {
def Idle 
def Open 
def Receiver
	def Open(server){
if(!Idle) throw new Exception('unfulfilled precondition: Idle')
	/*vars: [__TOKEN__, socket]*/

def __TOKEN__

def socket

	socket = new Socket(server.host, server.port)

this.Receiver =  socket
	
	

}
def Send(msg){
if(!Open) throw new Exception('unfulfilled precondition: Open')
	/*vars: [__TOKEN__, msg, OutgoingMessage, __LOOP_VAR__]*/

def __TOKEN__


def OutgoingMessage

def __LOOP_VAR__

	  OutgoingMessage = msg.getChars().toList().collate(5).collect{ new String(it.toArray(new char[0])) }
 
__LOOP_VAR__ = true
while(__LOOP_VAR__){
	def  m = OutgoingMessage.remove(0)
 

  if(OutgoingMessage.size() == 0){
    __TOKEN__ = [1,m]
  } else {
    __TOKEN__ = [0,m]
  }
   


  Receiver.getOutputStream().newObjectOutputStream().writeObject( __TOKEN__)
  
	
__LOOP_VAR__ = ( 0 == __TOKEN__[0] ) 
}

	
	

}
def Close(){
if(!Open) throw new Exception('unfulfilled precondition: Open')
	/*vars: [__TOKEN__]*/

def __TOKEN__

	
	
	

}

}