To run the program on the example protocol run the command:

java -jar petriCode.jar -o . -b ./res/groovy.bindings ./res/ProtocolModel.cpn


The result will show up in two files: Sender and Reciever.
