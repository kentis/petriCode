java -jar petriCode.jar  -o . -b java.bindings -b ./swprotocolJ.bindings -p prags.prags $@ SWProtocol.cpn 

