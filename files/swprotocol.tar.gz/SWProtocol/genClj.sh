java -jar petriCode.jar  -o . -b clojure.bindings -b ./swprotocolClj.bindings -p prags.prags $@ SWProtocol.cpn 
