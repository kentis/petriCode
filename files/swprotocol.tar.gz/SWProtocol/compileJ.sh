#!/bin/bash
javac -cp ~/usr/netty-4.0.10.Final/jar/all-in-one/netty-all-4.0.10.Final.jar *.java

mkdir -p Sender
mkdir -p Receiver

mv Sender*.class Sender/.
mv Receiver.class Receiver/.
