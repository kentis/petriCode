Dependencies for running the examples:
	- Groovy programming language
	- Bash
	- Java

Files:
	- SWProtocol.cpn -- The CPN model
	- gen*.sh  -- shell-scripts for code generation for vaious platforms
	- *.bindings -- Template bindings for the various platforms
	- *tmpls -- Templates for the various platforms
	- platforms -- Standard templates for the plattforms
	- run*.sh -- Shell-scripts for running the Clojure and Java implementaions
	- runner*.groovy -- Drivers for various languages
	- petriCode.jar -- The PetriCode code generation code
	- clojure-1.5.1.jar -- Clojure


Known Bugs:

	- On some platforms the generation scripts sometimes fails with the message 
          "java.lang.IllegalArgumentException: Compiler configuration must not be null."
          The message is temporary and rerunning the generation script a few times should
          fix it.
