
def senderAdd = """
s = Sender()
msg = [     [1,0,'Col'],         [2,0,'our'],         [3,0,'ed '],         [4,0,'Pet'],         [5,0,'ri '],          [6,0,'Net'], [7,1,'s']]
s.send(msg, {'host': 'localhost', 'port': 31338})
"""
def recieverAdd = """
r = Receiver()
m = r.receive(31338)
print "recieved: " + m
"""

def s1 = new File("./Sender1.py")
if(s1.exists() ) s1.delete()
s1.write(new File("./Sender.py").text)
//"cat Sender.py > Sender1.py".execute().waitFor()

def r1 = new File("./Receiver1.py")
if(r1.exists() ) r1.delete()
r1.write(new File("./Receiver.py").text)

//"cat Reciever.py > Reciever1.py".execute().waitFor()

s1.append(senderAdd)
r1.append(recieverAdd)

t = new Thread().start {
	p = "python ./Receiver1.py".execute()
	p.consumeProcessOutput(System.out, System.err)
	p.waitFor()

	//println p.text
}
Thread.sleep(1000)
p = "python Sender1.py".execute()
println p.text
p.consumeProcessOutput(System.out, System.err)

p.waitFor()
println "ferdig"
