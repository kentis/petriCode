java -jar petriCode.jar  -o . -b python.bindings -b ./swprotocolPy.bindings -p prags.prags $@ SWProtocol.cpn 
