#!/bin/bash
java -jar petriCode.jar "$@"
