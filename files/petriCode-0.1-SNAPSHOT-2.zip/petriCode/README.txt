To run the program on the example protocol run the command:

java -jar petriCode.jar -o . -b ./res/groovy.bindings model.cpn

