groovy -classpath /home/kent/usr/netty-4.0.10.Final/jar/all-in-one/netty-all-4.0.10.Final.jar runnerJ.groovy
