import clojure.lang.RT;
import clojure.lang.Var;

def eval = RT.var("clojure.core", "eval")
def read_string = RT.var("clojure.core", "load-string")

eval.invoke(read_string.invoke(new File("Sender.clj").text))
eval.invoke(read_string.invoke(new File("Receiver.clj").text))
def t = Thread.start {
   def res = RT.var("Receiver.Receiver", "receive").invoke(31339)
   println "Recieved $res"
}

Thread.sleep(1000)
def msg = [
        [1,0,'Col'],
        [2,0,'our'],
        [3,0,'ed '],
        [4,0,'Pet'],
        [5,0,'ri '],
        [6,0,'Net'],
        [7,1,'s'],
]

RT.var("Sender.Sender", "send").invoke(msg, [host:"localhost", port:31339])
Thread.sleep 1000
t.stop()
