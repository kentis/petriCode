groovy --classpath clojure-1.5.1.jar runnerClj.groovy
