#!/bin/bash
javac -cp ~/usr/netty-4.0.10.Final/jar/all-in-one/netty-all-4.0.10.Final.jar *.java
mv Sender*.class Sender/.
mv Receiver.class Receiver/.
