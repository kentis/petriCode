java -jar petriCode.jar  -o . -b groovy.bindings -b ./swprotocolGr.bindings -p prags.prags $@ SWProtocol.cpn 
