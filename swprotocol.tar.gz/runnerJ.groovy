def sender = new Sender.Sender()
def reciever = new Receiver.Receiver()

t = new Thread().start {
	def ret = reciever.receive(31339)	
	println "Recieved: ${ret}"
}

def msg = [
	[1,0,'Col'],
	[2,0,'our'],
	[3,0,'ed '],
	[4,0,'Pet'],
	[5,0,'ri '],
	[6,0,'Net'],
	[7,1,'s'],
]
sender.send(msg,[host:"localhost", port:31339])
println "ferdig"
t.stop()
System.exit(0);
